package main;

public class PROG02a_Ejer6
//No consigo corregir el fallo de la línea 3, creo que es porque he iniciado un java num y luego lo he modificado a class
public enum RazaPerro { Mastín, Terrier, Bulldog, Pekines, Caniche, Galgo }
public class PROG02a_Ejerc6 {
    public static void main(String[] args) {
        RazaPerro var1 = RazaPerro.Mastín;
        RazaPerro var2 = RazaPerro.Terrier;

        System.out.println(var1.compareTo(var2)); // Muestra comparación

        // Muestra posición de las variables
        System.out.println("Posición de var1: " + var1.ordinal());
        System.out.println("Posición de var2: " + var2.ordinal());
    }
}