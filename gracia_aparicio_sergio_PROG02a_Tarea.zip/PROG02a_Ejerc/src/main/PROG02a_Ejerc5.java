package main;

public class PROG02a_Ejerc5 {

	public static void main(String[] args) {
		  int segundos = 10068770; // Se puede poner los segundos a elegir
	        int minutos = segundos / 60;
	        int horas = minutos / 60;
	        int dias = horas / 24;

	        System.out.print(dias + " días, " + horas % 24 + " horas, " + minutos % 60 + " minutos");
	}

}
