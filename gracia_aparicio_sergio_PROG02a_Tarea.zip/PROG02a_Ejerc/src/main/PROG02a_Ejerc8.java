package main;

public class PROG02a_Ejerc8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int programacion = 15;
        int entornos = 12;
        int baseDatos = 8;

        int totalAlumnos = programacion + entornos + baseDatos;

        System.out.printf("Programación: %.1f%%\n", (programacion * 100.0) / totalAlumnos);
        System.out.printf("Entornos de Desarrollo: %.1f%%\n", (entornos * 100.0) / totalAlumnos);
        System.out.printf("Base de Datos: %.1f%%\n", (baseDatos * 100.0) / totalAlumnos);
    }
}

