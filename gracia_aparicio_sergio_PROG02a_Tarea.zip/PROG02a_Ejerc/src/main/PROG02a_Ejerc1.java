package main;

public class PROG02a_Ejerc1 {

	public static void main(String[] args) {
		 final int VALOR_MAXIMO = 1500; // Valor máximo no modificable
	        boolean tieneCarnetConducir = true; // Si tiene carnet de conducir
	        String mesDelAno = "05"; // Mayo 
	        String nombreYApellidos = "Sergio Gracia"; // Nombre y apellidos
	        char sexo = 'M'; // Sexo: masculino o femenino (M-F)
	        int milisegundosDesde1970 = 999999999; // No sé calcular dichos milisegundos, añado tiempo exagerado
	        double saldoCuentaBancaria = 358.12; // Saldo
	        int distanciaKmsTierraJupiter = 635000000; // Distancia en km

	        // Mostrar valores sin usar println
	        System.out.print(VALOR_MAXIMO + "\n" +
	                         tieneCarnetConducir + "\n" +
	                         mesDelAno + "\n" +
	                         nombreYApellidos + "\n" +
	                         sexo + "\n" +
	                         milisegundosDesde1970 + "\n" +
	                         saldoCuentaBancaria + "\n" +
	                         distanciaKmsTierraJupiter + "\n");
	

	}

}
