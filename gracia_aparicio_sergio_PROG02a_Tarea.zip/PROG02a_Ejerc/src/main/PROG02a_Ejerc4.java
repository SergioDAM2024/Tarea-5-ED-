package main;

public class PROG02a_Ejerc4 {

	public static void main(String[] args) {
		int edad = 20; // Poner cualquiera
        String mensaje = (edad >= 18) ? "Mayor de edad" : "Menor de edad";
        System.out.println (mensaje);

	}

}
