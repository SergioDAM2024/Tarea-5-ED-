package main;

public class PROG02a_Ejerc7 {
// Se buscó en internet la fórmula para realizar la ecuación
	public static void main(String[] args) {
		 double C1 = 6; // Elegir valor
	        double C2 = 8; // Elegir valor
	        double x = -C2 / C1;
	        System.out.printf("El resultado es: %.4f\n", x);
	    }
	}