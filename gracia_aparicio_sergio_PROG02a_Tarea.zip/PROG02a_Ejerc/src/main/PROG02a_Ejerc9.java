package main;

public class PROG02a_Ejerc9 {

	public static void main(String[] args) {
		 int año = 2024; // Introducir año
	        boolean esBisiesto = (año % 4 == 0 && año % 100 != 0) || (año % 400 == 0);
	        System.out.println(año + " es bisiesto: " + esBisiesto);
	   }
}
